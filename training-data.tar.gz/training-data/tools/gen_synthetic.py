"""
Generate 4 classic synthetic test patterns into training-data/synthetic/.
These are computer-generated, public-domain, hard-edge patterns that:
  · Stress JPEG block boundaries (sharp edges → ringing at Δ > 12)
  · Demonstrate quantisation banding on flat regions
  · Make compression artifacts immediately visible to the eye
"""
from PIL import Image, ImageDraw, ImageFont
import math
import os

OUT = '/home/claude/repo/training-data/synthetic'
os.makedirs(OUT, exist_ok=True)

# ───────── 1. SMPTE color bars ──────────────────────────────────
def smpte_bars():
    img = Image.new('RGB', (768, 576), 'black')
    d = ImageDraw.Draw(img)
    # Top 2/3 — 7 main color bars (75% saturation)
    bars_top = [
        (192, 192, 192),  # gray
        (192, 192,   0),  # yellow
        (  0, 192, 192),  # cyan
        (  0, 192,   0),  # green
        (192,   0, 192),  # magenta
        (192,   0,   0),  # red
        (  0,   0, 192),  # blue
    ]
    bw = 768 / 7
    for i, c in enumerate(bars_top):
        d.rectangle([int(i * bw), 0, int((i + 1) * bw), 384], fill=c)
    # Middle — reverse blue→gray
    bars_mid = [
        (  0,   0, 192),
        ( 19,  19,  19),
        (192,   0, 192),
        ( 19,  19,  19),
        (  0, 192, 192),
        ( 19,  19,  19),
        (192, 192, 192),
    ]
    for i, c in enumerate(bars_mid):
        d.rectangle([int(i * bw), 384, int((i + 1) * bw), 432], fill=c)
    # Bottom — pluge bars
    pluge = [
        (  0,  33,  76),  # I
        (255, 255, 255),  # white
        ( 50,   0, 106),  # Q
        ( 19,  19,  19),  # gray
        (  9,   9,   9),  # super-black
        ( 19,  19,  19),
        ( 29,  29,  29),  # black+
        ( 19,  19,  19),
    ]
    seg = 768 / 8
    for i, c in enumerate(pluge):
        d.rectangle([int(i * seg), 432, int((i + 1) * seg), 576], fill=c)
    img.save(os.path.join(OUT, 'smpte-color-bars.png'), optimize=True)
    print('  smpte-color-bars.png')

# ───────── 2. Checkerboard (pure black/white edges) ─────────────
def checkerboard():
    img = Image.new('L', (512, 512), 0)
    d = ImageDraw.Draw(img)
    cell = 32
    for r in range(0, 512, cell):
        for c in range(0, 512, cell):
            if ((r // cell) + (c // cell)) % 2 == 0:
                d.rectangle([c, r, c + cell, r + cell], fill=255)
    img.save(os.path.join(OUT, 'checkerboard-32px.png'), optimize=True)
    print('  checkerboard-32px.png')

# ───────── 3. Zone plate (frequency response test) ──────────────
def zone_plate():
    size = 512
    img = Image.new('L', (size, size))
    px = img.load()
    cx, cy = size // 2, size // 2
    k = 0.0008
    for y in range(size):
        for x in range(size):
            r2 = (x - cx) ** 2 + (y - cy) ** 2
            v = 0.5 + 0.5 * math.cos(k * r2)
            px[x, y] = int(v * 255)
    img.save(os.path.join(OUT, 'zone-plate.png'), optimize=True)
    print('  zone-plate.png')

# ───────── 4. Bar chart with text labels (typical synthetic doc) ─
def bar_chart():
    img = Image.new('RGB', (640, 480), (248, 248, 246))
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 11)
        tfont = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 14)
    except (OSError, IOError):
        font = ImageFont.load_default()
        tfont = font
    # Title
    d.text((140, 12), 'COMPRESSION RATIO BY IMAGE TYPE', fill=(10, 10, 10), font=tfont)
    # Axes
    d.line([(80, 50), (80, 410)], fill=(20, 20, 20), width=2)
    d.line([(80, 410), (600, 410)], fill=(20, 20, 20), width=2)
    # Grid
    for i in range(1, 6):
        y = 410 - (i * 60)
        d.line([(80, y), (600, y)], fill=(216, 216, 210), width=1)
        d.text((50, y - 6), str(i * 5), fill=(80, 80, 80), font=font)
    # Bars (solid color, hard edges)
    bars = [
        ('Natural',     280, (37, 99, 235)),
        ('AI Gen',      315, (139, 92, 246)),
        ('Synthetic',   240, (6, 182, 212)),
        ('Fingerprint', 60,  (245, 158, 11)),
        ('MRI',         55,  (239, 68, 68)),
    ]
    bw = 70
    gap = 30
    x = 110
    for name, h, color in bars:
        d.rectangle([x, 410 - h, x + bw, 410], fill=color, outline=(20, 20, 20))
        d.text((x + 4, 415), name, fill=(60, 60, 60), font=font)
        d.text((x + 16, 410 - h - 16), f'{h//12}:1', fill=(20, 20, 20), font=font)
        x += bw + gap
    # Y-axis label
    d.text((20, 200), 'CR', fill=(60, 60, 60), font=font)
    img.save(os.path.join(OUT, 'bar-chart-cr.png'), optimize=True)
    print('  bar-chart-cr.png')

if __name__ == '__main__':
    print('Generating synthetic test patterns...')
    smpte_bars()
    checkerboard()
    zone_plate()
    bar_chart()
    print('Done.')
